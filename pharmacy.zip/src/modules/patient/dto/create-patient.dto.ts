export class CreatePatientDto {}
