export class CreatePharmacyDocumentDto {}
