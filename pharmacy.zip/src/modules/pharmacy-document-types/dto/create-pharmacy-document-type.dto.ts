export class CreatePharmacyDocumentTypeDto {}
